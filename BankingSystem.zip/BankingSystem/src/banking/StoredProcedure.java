package banking;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class StoredProcedure {
	Connection con;
	public void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_db","root","svecw@123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void CreateCallableProcedure(int account_number) {
		try {
			CallableStatement cs=con.prepareCall("{call get_account_details(?,?)}");
			cs.setInt(1,account_number);
			cs.registerOutParameter(2,Types.VARCHAR);
			cs.execute();
			System.out.println("Holder Name: "+cs.getString(2));
			System.out.println();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void createCallableFunction(int account_number) {
		try {
			CallableStatement cs=con.prepareCall("{?=call get_holdername_from_account(?)}");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.setInt(2,account_number);
			cs.execute();
			System.out.println("Holder Name: "+cs.getString(1));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
