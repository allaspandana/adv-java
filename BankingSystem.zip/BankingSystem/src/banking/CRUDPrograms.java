package banking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CRUDPrograms {
	private static final String String = null;
	Connection con;
	PreparedStatement pstmt;
	public void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_db","root","svecw@123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	public void getAllDetails() {
		try {
			String query="select*from account";
			pstmt= con.prepareStatement(query);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				System.out.println("account number:"+rs.getInt(1));
				System.out.println("holder name:"+rs.getString(2));
				System.out.println("branch:"+rs.getString(3));
				System.out.println("balance:"+rs.getInt(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	public void insertDetails(int account_number,String holder_name,String branch,int balance){
		try {
			String query = "INSERT INTO account VALUES(?,?,?,?)";
			pstmt=con.prepareStatement(query);
			pstmt.setInt(1,account_number);
			pstmt.setString(2,holder_name);
			pstmt.setString(3,branch);
			pstmt.setInt(4,balance);
			int rows=pstmt.executeUpdate();
			System.out.println("Rows Inserted:"+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void updateDetails(int account_number,String branch) {
		try {
			String query = "UPDATE account SET branch=? WHERE account_number=?";
			pstmt=con.prepareStatement(query);
			pstmt.setString(1, branch);
			pstmt.setInt(2, account_number); 
			int rows=pstmt.executeUpdate();
			System.out.println("Rows Updated:"+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void deleteDetails(int account_number) {
		try {
			String query="delete from account where account_number=?";
			pstmt=con.prepareStatement(query);
			pstmt.setInt(1,account_number);
			int rows=pstmt.executeUpdate();
			System.out.println("Rows Deleted:"+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
