package banking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Bank {
	Connection con;
	Statement stmt;
	public void createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/banking_db","root","svecw@123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void viewDetails() {
		try {
			String query="select*from account";
			stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next()) {
				System.out.println("account number:"+rs.getInt(1));
				System.out.println("holder name:"+rs.getString(2));
				System.out.println("branch:"+rs.getString(3));
				System.out.println("balance:"+rs.getInt(4));
		} 
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
}
	public void insertDetails() {
		try {
			int account_number=1209;
			String holder_name="sai ram";
			String branch="kakinada";
			int balance=100000;
			String query = "INSERT INTO account VALUES("
			        + account_number + ",'"
			        + holder_name + "','"
			        + branch + "','"
			        + balance + "')";
			Statement stmt=con.createStatement();
			int rows=stmt.executeUpdate(query);
			System.out.println(rows+"inserted");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	public void updateDetails() {
		try {
			int account_number=1201;
			String holder_name="nani";
			String query = "UPDATE account SET holder_name='" + holder_name
			        + "' WHERE account_number=" + account_number;
			Statement stmt=con.createStatement();
			int row=stmt.executeUpdate(query);
			System.out.println(row+"update recorded");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
}
